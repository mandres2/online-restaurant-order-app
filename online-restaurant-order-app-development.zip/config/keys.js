module.exports = {
  mongoURI: "mongodb+srv://whddkf2004:whddkf2004@project3-user-authentication-6weoj.mongodb.net/test?retryWrites=true&w=majority",
  secretOrKey: "secret"
};
