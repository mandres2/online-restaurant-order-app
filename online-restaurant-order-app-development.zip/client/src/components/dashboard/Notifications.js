import React from 'react';

const Notifications = () => {
  return (
    <div>
      <p>Notifications</p>
    </div>
  )
}

export default Notifications;